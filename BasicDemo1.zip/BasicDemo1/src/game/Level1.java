package game;

import city.cs.engine.Body;
import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;
/** Level1 contains all of the methods and objects from GameLevel(base level) and adds onto it*/
public class Level1 extends GameLevel{
    /**Contains the new static bodies and positions for Level1,
     * @param game The game level1 occurs in. */
    public Level1(Game game){
        super(game);
        // make the ground, grounds and platforms are staticBody types they dont change.
        Shape groundShape = new BoxShape(11, 0.5f);
        Body ground = new StaticBody(this, groundShape);
        ground.setPosition(new Vec2(0, -11.5f));
        // make a platform

        getP1().setPosition(new Vec2(-9, 5.5f));
        //getP1().setAlwaysOutline(true);


        getP2().setPosition(new Vec2(-2, 1.0f));


        getP3().setPosition(new Vec2(5, -5.0f));


    }
    /**Contains the new dynamic bodies and positions for Level1,
     * @param game The game level1 occurs in. */
    public void populate(Game game){ //all dynamic objects and their related operations are put in here to be preserved when save and load are called.
        super.populate(game);

        getRoo().setPosition(new Vec2(8, -10));

        BombContact contact = new BombContact(getRoo());
        getRoo().addCollisionListener(contact);

        getBomb6().setPosition(new Vec2(-6.2f, 16f));

        BombSpawn spawn6 = new BombSpawn(getBomb6(), this);
        getBomb6().addCollisionListener(spawn6);
    }
    /** Getter for the level name, used to save and load game state in GameSaverLoader
     * @return Level1 */
    @Override
    public String getLevelName() {
        return "Level1";
    }



}
