package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;
/**Base level */
public abstract class GameLevel extends World{ // GameWorld is a subclass of world, used to encapsulate platforms and characters.

    private Roo roo;
    private Bomb bomb6;
    private Bomb bomb1;
    private Platform p1;
    private Platform p2;
    private Platform p3;
    private Joey joey1;
    int secondsPassed = 1;
    /**Tracks the amount of bombs generated when there is a BombSpawn collision. Used in the createBomb method.*/
    int instances = 0;
    int instances2 = 0;
    /**Base level which contains dynamic and static bobies that interact with eachother. all levels will have the bodies and methods below
     * <p>
     * @param game used in Game */
    public GameLevel(Game game) {
        //super();
        // make the ground, grounds and platforms are staticBody types they dont change.
        Shape groundShape = new BoxShape(11, 0.5f);
        Body ground = new StaticBody(this, groundShape);
        ground.setPosition(new Vec2(0, -11.5f));
        // make a platform
        p1 = new Platform( this);
        p2 = new Platform( this);
        p3 = new Platform( this);

    }
    /**Contains all dynamic bodies and their collision listeners.
     * @param game called in game. */
    public void populate(Game game){
        // add a character object, instantiates character instances into Game
        roo = new Roo(this);
        // the below are all the bombs that will be added into the world.
        bomb6 = new Bomb(this);
        bomb1 = new Bomb(this);
        //bomb1.setAlwaysOutline(true);
        // add the second character object
        joey1 = new Joey(this);
        //joey1.setAlwaysOutline(true); //shows polygonEditor character shape outline
        joey1.setPosition(new Vec2(-9, 5.8f));
        JoeyEncounter contact2 = new JoeyEncounter(this, game, roo);
        roo.addCollisionListener(contact2);
    }
    /** Getter for the Roo object
     * @return roo object*/
    public Roo getRoo(){ return roo; }
    /**Setter for the Roo object
     * @param  r object of Roo
     */
    public void setRoo(Roo r){ roo = r; }
    /** Getter of the bomb6 Bomb object
     **/
    public Bomb getBomb6(){ return bomb6; }
    /** Getter of the bomb1 Bomb object
     *@return bomb6 object   */
    public Bomb getBomb1(){return bomb1;}
    /**Getter for the joey object
     * @return joey object*/
    public Joey getJoey(){ return joey1;}
    /** Getter for platform1
     * @return p1 */
    public Platform getP1(){ return p1;}
    /** Getter for p2
     * @return p2 */
    public Platform getP2() {return p2;}
    /** Getter for p3
     * @return p3 */
    public Platform getP3(){return p3;}
    /**Upon a BombSpawn collision this method gets called to create a new Bomb object and specify its position
     * the instances variable determines how many bomb objects get created after a bomb collision*/
    public void createBomb(){ //This method is called from the BombSpawn class to add a bomb to the game and at specific position.
        Bomb bomb = new Bomb(this);
        bomb.setPosition(new Vec2(-4.2f, 16f));
        BombSpawn spawn = new BombSpawn(bomb, this);
        bomb.addCollisionListener(spawn);//When a bomb makes contact with a platform a new bomb is created at the postion set above.
        instances++;//Used to limit the amount of bombs created when there is contact between a bomb and a platform.
    }
    public abstract String getLevelName();

}
