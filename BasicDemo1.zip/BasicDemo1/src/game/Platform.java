package game;

import city.cs.engine.*;
/**Shape and image for Platform objects */
public class Platform extends StaticBody { //class of static platforms to create obects from in other classes.
    private static final Shape platformShape = new PolygonShape(-2.59f,1.16f,
            3.17f,0.75f,
            3.13f,-0.76f,
            -2.56f,-0.73f,
            -2.74f,1.04f);

    private static final BodyImage image =
            new BodyImage("data/platform.png", 6f);
    /**Allows new platform objects to be created
     * @param world Level a platform object is created in */
    public Platform(World world) {
        super(world, platformShape);
        addImage(image);
    }
}
