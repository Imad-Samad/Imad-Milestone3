package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
/**When a Bomb object collides with a Platform object in level 3, a new bomb is created to fall, this process is looped*/
public class BombSpawnL3 implements CollisionListener {
    private Bomb bomb1;
    private Level3 gameLevel3;
    private int newBombs2;
    /**@param b1 The Bomb objet that collides with the platform.
     * @param l3 This class only occurs for level3.         */
    public BombSpawnL3(Bomb b1, Level3 l3){
        this.bomb1 = b1;
        this.gameLevel3 = l3;
    }
    @Override
    public void collide(CollisionEvent r){
        if (r.getOtherBody() instanceof Platform){
            newBombs2++;
            if (gameLevel3.instances2 < 100 && newBombs2 <= 2) { //Bomb spawner specifially for level 3.
                gameLevel3.updateCreateBomb();
            }
        }
    }
}
