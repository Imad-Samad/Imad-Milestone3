package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
/**When a Bomb object collides with a Platform object in level 2, a new bomb is created to fall, this process is looped*/
public class BombSpawnL2 implements CollisionListener {
    private Bomb bomb1;
    private Level2 gameLevel2;
    private int newBombs2;
    /**@param b1 The Bomb objet that collides with the platform.
     * @param l2 this class only occurs for level2.         */
    public BombSpawnL2(Bomb b1, Level2 l2){
        this.bomb1 = b1;
        this.gameLevel2 = l2;
    }
    @Override
    public void collide(CollisionEvent r){
        if (r.getOtherBody() instanceof Platform){ //Bomb spawner sepcifially for level2.
            newBombs2++;
            if (gameLevel2.instances2 < 100 && newBombs2 <= 2) { //Difference between this class and BombSpan is that 2 bombs fall simultaneously instad of 1, Making it twice as hard.
                gameLevel2.updateCreateBomb();
            }
        }
    }
}
