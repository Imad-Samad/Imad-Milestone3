package game;

import city.cs.engine.Body;
import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;
/** Level2 contains all of the methods and objects from GameLevel(base level) and adds onto it*/
public class Level2 extends GameLevel{
    /**Contains the new static bodies and positions for Level2,
     * @param game The game level1 occurs in. */
    private Platform p4;
    public Level2(Game game){
        super(game);
        // make the ground, grounds and platforms are staticBody types they dont change.
        Shape groundShape = new BoxShape(11, 0.5f);
        Body ground = new StaticBody(this, groundShape);
        ground.setPosition(new Vec2(0, -11.5f));
        // make a platform

        getP1().setPosition(new Vec2(-9, 5.5f));
        //getP1().setAlwaysOutline(true);


        getP2().setPosition(new Vec2(-2, 1.0f));


        getP3().setPosition(new Vec2(5, -5.0f));
        //adds a new platform to level 2.
        p4 = new Platform( this);
        p4.setPosition(new Vec2(-11, -3.5f));


    }
    /**Contains the new dynamic bodies and positions for Level2,
     * @param game The game level2 occurs in. */
    public void populate(Game game){//all dynamic objects and their related operations are put in here to be preserved when save and load are called.
        super.populate(game);
        getRoo().setPosition(new Vec2(8, -10));
        BombContact contact = new BombContact(getRoo());
        getRoo().addCollisionListener(contact);

        getBomb6().setPosition(new Vec2(-6.2f, 16f));
        BombSpawn spawn6 = new BombSpawn(getBomb6(), this);
        getBomb6().addCollisionListener(spawn6);

        getBomb1().setPosition(new Vec2(4.2f, 16f));
        BombSpawnL2 spawn3 = new BombSpawnL2(getBomb1(), this);
        getBomb1().addCollisionListener(spawn3);
    }
    /** Getter for the level name, used to save and load game state in GameSaverLoader
     * @return Level2 */
    @Override
    public String getLevelName() {
        return "Level2";
    }
    /**This method is called from the BombSpawnL2 class to add a bomb to the game and at specific position in level2. */
    public void updateCreateBomb(){ //This method is called from the BombSpawnL2 class to add a bomb to the game and at specific position in level2.
        Bomb bomb1 = new Bomb(this);
        bomb1.setPosition(new Vec2(4.2f, 16f));
        BombSpawnL2 spawn1 = new BombSpawnL2(bomb1, this);//When a bomb makes contact with a platform a new bomb is created at the postion set above.
        bomb1.addCollisionListener(spawn1);//Used to limit the amount of bombs created to 2 when there is contact between a bomb and a platform.
        instances2++;
    }

}
