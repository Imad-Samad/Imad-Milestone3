package game;

import city.cs.engine.*;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;

public class Robot extends DynamicBody {
    private static SoundClip robotSound; //new sound for robot objects collisions with Roo objects.

    static {
        try{
            robotSound = new SoundClip("data/loosing.wav");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e){
            System.out.println(e);
        }
    }

    private static final Shape robotShape = new CircleShape(0.75f);
    private static final BodyImage image =
            new BodyImage("data/blackball.png", 2f);

    public Robot(World world) {
        super(world, robotShape); //adds robot to the world and its shape.
        addImage(image);
    }
    @Override
    public void destroy(){
        robotSound.play();
        super.destroy();
    }
}
