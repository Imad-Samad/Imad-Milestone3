package game;

import city.cs.engine.SoundClip;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

public class RooController implements KeyListener {

    private Roo roo;
    private Game game;
    private static SoundClip jumpSound;
    private static final float WALKING_SPEED = 4;

    public RooController(Roo s, Game g){
        roo = s;
        game = g;
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        // other key commands omitted
        if (code == KeyEvent.VK_A) { // user presses 'A' to move the character left.
            roo.startWalking(-WALKING_SPEED);
        } else if (code == KeyEvent.VK_D) { // user presses 'D' to move the character right.
            roo.startWalking(WALKING_SPEED);
        }
        if (code == KeyEvent.VK_W){
            roo.jump(16);// when the w key is pressed the character is elevated upwards at a speed of 16.
        }
        else if (code == KeyEvent.VK_S){
            try {
                GameSaverLoader.save(game.getLevel(), "data/save.txt");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            System.out.println("Save");
        }
        else if (code ==KeyEvent.VK_L){
            try {
                GameLevel level = GameSaverLoader.load(game,"data/save.txt");
                game.setLevel(level);
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            System.out.println("Load");
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_A) {
            roo.stopWalking();
        } else if (code == KeyEvent.VK_D) {
            roo.stopWalking();
        }

    }
    public void updateRoo(Roo roo){this.roo =roo;}
}
