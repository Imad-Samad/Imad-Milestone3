package game;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
/**Checks if the mouse is within the area of the GUI, then allows the Roo controls to work*/
public class GiveFocus implements MouseListener {

    private Myview view;

    public GiveFocus(Myview v){
        this.view = v;
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        view.requestFocus();
    } //checks if the mouse is within the area of the GUI, then allows the Roo controls to work.

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
