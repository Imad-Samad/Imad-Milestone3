package game;

import city.cs.engine.UserView;
import city.cs.engine.World;

import javax.swing.*;
import java.awt.*;
/**my view is used to encapsulate view methods and variables. */
public class Myview extends UserView { // my view is used to encapsulate view methods and variables.
    private Image background; // background variable of type Image
    private Game game;
    private Roo roo;
    /**@param w world/level the view is in
     * @param g game the view is in
     * @param r roo object that is in the view
     * @param width of the view
     * @param height of the view
     * */
    public Myview(World w, Game g, Roo r, int width, int height) { //MyView constructor
        super(w, width, height);
        background = new ImageIcon("data/brickwall.gif").getImage(); // background image is the brickwall gif from the data folder
        game = g;
        roo = r;
    }
    /** Used for background doesn't change*/
        @Override
        protected void paintBackground (Graphics2D g){
            g.drawImage(background, 0, 0, getWidth(), getHeight(), this); //positions the background image into the view
        }
    /**Used for life counter, changed when life counter changes */
        @Override
        protected void paintForeground(Graphics2D g) { //Sets the life-count in the top right corner of the game, changing when it is reduced.

        g.drawString("Lives remaining: " + roo.getLifeCount(), 10, 20);

        }
        /**Updates the roo object so the life counter changes as levels progress.
         * @param roo New roo object after move to new level */
        public void updateRoo(Roo roo){
        this.roo = roo;
        } //this is called in goToNextLevel to update the life-count while the game is occuring.
}
