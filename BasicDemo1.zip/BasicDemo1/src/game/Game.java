/**
 * @author Imad Samad
 * @version Final Version
 * @since March 2021
 */
package game;

import city.cs.engine.SoundClip;
import city.cs.engine.UserView;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
/**
 * Creates the game by utilising all the other classes
 */
public class Game {

    /** The World in which the bodies move and interact. */
    private GameLevel level;

    /** A graphical display of the world (a specialised JPanel). */
    private Myview view;
    private WideView wideView; //This is the GUI which shows the whole view of the game, while Myview is linked to a tracker that zooms in on and follows Roo.
    /**Adds character controls through user input to thegame */
    private RooController controller;
    /** Boolean used to determine the state of a game at any given time*/
    private Boolean playing;

    /** Variable used to add background music to the game. */
    private SoundClip gameMusic;

    /** Initialise a new Game. */
    public Game() {

        // make the world
        //world = new World();

        level = new Level1(this);
        level.populate(this);// Adds all the collision listeners, spawners, set positioners, and objects of dynamic bodies in Level1 to the game.
        System.out.println("Your Joey has found itself in an awkward position above... try to rescue it but do so carefully... "); // Opening message.

        try {
            gameMusic = new SoundClip("data/music.wav");   // Open an audio input stream, backing music.
            gameMusic.loop();  // Set it to continous playback (looping)
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }

        /* for(int i = 0; i <= 15; i++) {
            Shape boxesShape = new BoxShape(1, 0.5f);
            DynamicBody boxes = new DynamicBody(world, boxesShape);
            boxes.setPosition(new Vec2(0, -10.5f));
            i = i+1;
        }*/
        // make a view
        view = new Myview(level,this , level.getRoo(),  500, 500);
        wideView = new WideView(level, this, level.getRoo(), 500, 400);
        // view.setGridResolution(1);

        controller = new RooController(level.getRoo(), this);
        view.addKeyListener(controller); // implements user actions and reflects them in view.
        view.addMouseListener(new GiveFocus(view)); //When the mouse cursor is over the GUI user input from the keyboard will be implemented.
        wideView.addKeyListener(controller);//Input from keyboard is shown in the wideView aswell.
        level.addStepListener(new Tracker(view, level.getRoo())); // view tracks roo.

        // add the view to a frame (Java top level window)
        final JFrame frame = new JFrame("Basic world");
        frame.add(view);

        ControlPanel buttons = new ControlPanel(this); // Adds the ControlPanel GUI to the top of frame.
        frame.add(buttons.getMainPanel(), BorderLayout.NORTH); //Allows user to interact with buttons to control elements of the game.

        wideView.setZoom(7); //Sets size of wideView in the bottom of the GUI
        frame.add(wideView, BorderLayout.SOUTH);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        // don't let the frame be resized
        frame.setResizable(false);
        // size the frame to fit the world view
        frame.pack();
        // finally, make the frame visible
        frame.setVisible(true);
        // uncomment this to make a debugging view
        //JFrame debugView = new DebugViewer(world, 500, 500);
        // start our game world simulation!
        level.start();
    }
    /**Sets the level to the state below
     * <p>
     * Allows Load to set the level to a state that was previously saved. This is called when load is called.
     *
     * @param level Level that user is currently in.
     * */
    public void setLevel(GameLevel level){ //Allows Load to set the level to a state that was previously saved. This is called when load is called.
        //stop the current level
        this.level.stop();
        Roo roo = this.level.getRoo();
        //create the new (appropriate) level
        //level now refers to new level
        this.level = level; //Makes the game start from the current level.
        //change the view to look into new level
        view.setWorld(this.level);
        wideView.setWorld(this.level);
        this.level.addStepListener(new Tracker(view, this.level.getRoo()));

        //change the controller to control the
        //roo in the new world
        controller.updateRoo(this.level.getRoo()); //updates Roo for controls to work
        view.updateRoo(this.level.getRoo()); // updates roo lifecount.
        wideView.setZoom(7);
        //start the simulation in the new level
        this.level.start();
    }
    /** Allows the user to progress into higher levels
     * <p>
     */
    public void goToNextLevel(){
        if (level instanceof Level1){
            //stop the current level
            level.stop();
            Roo roo = level.getRoo();
            //create the new (appropriate) level
            //level now refers to new level
            level = new Level2(this);
            level.populate(this);
            //change the view to look into new level
            view.setWorld(level);
            wideView.setWorld(level);
            level.addStepListener(new Tracker(view, level.getRoo())); //keeps tracker on Roo in new level.

            //change the controller to control the
            //roo in the new world
            controller.updateRoo(level.getRoo());//updates Roo for controls to work
            view.updateRoo(level.getRoo());//used to update roo lifecount from the view class.
            wideView.setZoom(7);
            //start the simulation in the new level
            level.start();
        }
        else if (level instanceof Level2){
            level.stop();
            level = new Level3(this);
            level.populate(this);
            view.setWorld(level);
            wideView.setWorld(level);
            level.addStepListener(new Tracker(view, level.getRoo()));//keeps tracker on Roo in new level.
            controller.updateRoo(level.getRoo());//updates Roo for controls to work.
            view.updateRoo(level.getRoo());//used to update roo lifecount from the view class.
            wideView.setZoom(7);
            level.start();
        }
        else if (level instanceof  Level3){
            level.populate(this);
            wideView.setWorld(level);
            level.addStepListener(new Tracker(view, level.getRoo()));//keeps tracker on Roo in new level.
            controller.updateRoo(level.getRoo());//updates Roo for controls to work.
            view.updateRoo(level.getRoo());//used to update roo lifecount from the view class.
            wideView.setZoom(7);
            level.start();
            System.out.println("Well done! Game complete.");//End game message.
            System.exit(0);
        }



    }
    //The below code is for the buttons in the ControlPanel GUI
    /** Attached to a GUI button in ControlPanel to pause and resume the game in its current state*/
    public void pause(){ //makes use of a boolean variable. when the pause and resume buttons are pressed the state of the boolean variable alernates. This controls the level to stop or start.
        if (playing==true){
            level.stop();
        }
        else {level.start();}
    }
    /** Sets the boolean "playing" to true.
     * <p>
     * Used for pause and resume button, if playing is true you can pause the game.
     * @return Boolean playing*/
    public Boolean setPlayingTrue(){ //setter to set the boolean variable to true.
        playing = true;
        return playing;
    }
    /**Sets the boolean "playing" to false
     *<p>
     *Used for pause and resume button, if playing is false you can resume the game.
     * @return Boolean playing*/
    public Boolean setPlayingFalse(){ ////setter to set the boolean variable to false.
        playing = false;
        return playing;
    }
    /** @return the current level*/
    public GameLevel getLevel(){
    return level;
    }
    /** Run the game. */
    public static void main(String[] args) {

        new Game();
    }
}
