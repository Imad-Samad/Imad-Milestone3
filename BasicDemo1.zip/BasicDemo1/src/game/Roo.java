package game;

import city.cs.engine.*;

public class Roo extends Walker {
    private static final Shape rooShape = new PolygonShape(
            -0.11f,2.8f,
            1.87f,2.38f,
            1.99f,1.29f,
            2.24f,-2.32f,
            -1.12f,-2.37f,
            -1.44f,2.21f);

    private static final BodyImage image =
            new BodyImage("data/kangaroo1.png", 5f);

    public Roo(World world) {
        super(world, rooShape); //adds roo to the world and its shape.
        addImage(image);
    }
    private int lifeCount = 100;
    private int score = 0;
    public void decrementLives(){ // method to reduce lives when experiencing a collision with a bomb. Refer to BombContact...
        lifeCount= lifeCount-1;
        if (lifeCount == 1) {
            System.out.println("Whoa! That's 1 life gone you've only got " + lifeCount + " left, tread CAREFULLY!");
            score = score + 50;
        }
        else if (lifeCount == 2) {
            score = score + 100;
        }
        else if (lifeCount == 3){
            score = score + 150;
        }
    }
    public int getLifeCount(){
        return lifeCount;
    }
    public void setLifeCount(int lc){
        lifeCount = lc;
    }
    public int getScore(){
        return score;
    }
}
