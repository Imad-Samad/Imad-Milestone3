package game;

import city.cs.engine.Body;
import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;
/** Level3 contains all of the methods and objects from GameLevel(base level) and adds onto it*/
public class Level3 extends GameLevel{
    private Platform p4;
    /**Contains the new static bodies and positions for Level3,
     * @param game The game level3 occurs in. */
    public Level3(Game game){
        super(game);
        // make the ground, grounds and platforms are staticBody types they dont change.
        Shape groundShape = new BoxShape(11, 0.5f);
        Body ground = new StaticBody(this, groundShape);
        ground.setPosition(new Vec2(0, -11.5f));
        // make a platform

        getP1().setPosition(new Vec2(-9, 5.5f));
        //getP1().setAlwaysOutline(true);


        getP2().setPosition(new Vec2(-2, 1.0f));


        getP3().setPosition(new Vec2(5, -5.0f));

        p4 = new Platform( this);
        p4.setPosition(new Vec2(-11, -3.5f));



    }
    /**Contains the new dynamic bodies and positions for Level3,
     * @param game The game level3 occurs in. */
    public void populate(Game game){//all dynamic objects and their related operations are put in here to be preserved when save and load are called.
        super.populate(game);
        getRoo().setPosition(new Vec2(8, -10));

        BombContact contact = new BombContact(getRoo());
        getRoo().addCollisionListener(contact);

        RobotContact contact3 = new RobotContact(getRoo());
        getRoo().addCollisionListener(contact3);

        getBomb6().setPosition(new Vec2(-6.2f, 16f));
        BombSpawn spawn6 = new BombSpawn(getBomb6(), this);
        getBomb6().addCollisionListener(spawn6);

        getBomb1().setPosition(new Vec2(4.2f, 16f));
        BombSpawnL3 spawn3 = new BombSpawnL3(getBomb1(), this);
        getBomb1().addCollisionListener(spawn3);

        for (int i=0; i<3; i++){ //Loops the amount of objects of this class is generates in level 3.
            Robot robots = new Robot(this);
            //robots.setPosition(new Vec2(-9+i*2f,-11.5f));
            robots.setLinearVelocity(new Vec2(-6.5f+i*2f,0f));
        }
    }

    /** Getter for the level name, used to save and load game state in GameSaverLoader
     * @return Level2 */
    @Override
    public String getLevelName() {
        return "Level3";
    }
    /**This method is called from the BombSpawnL3 class to add a bomb to the game and at specific position in level3. */
    public void updateCreateBomb(){//This method is called from the BombSpawnL3 class to add a bomb to the game and at specific position in level3.
        Bomb bomb1 = new Bomb(this);
        bomb1.setPosition(new Vec2(4.2f, 16f));
        BombSpawnL3 spawn1 = new BombSpawnL3(bomb1, this);//When a bomb makes contact with a platform a new bomb is created at the postion set above.
        bomb1.addCollisionListener(spawn1);//Used to limit the amount of bombs created to 2 when there is contact between a bomb and a platform.
        instances2++;
    }

}

