package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;

public class RobotContact implements CollisionListener {
    private Roo roo;

    public RobotContact(Roo s){
        this.roo = s;
    }
    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof Robot) { // when the kangaroo collides with a bomb the lifeCount reduces until 0. If lifeCount = 0, game over.
            e.getReportingBody().destroy();
            e.getOtherBody().destroy();
            System.out.println("Game Over! Hitting a spike-bomb takes all your lives away. You've run out of lives. Press Quit to exit or press Load (or the L key) to continue from where you saved.");

        }
    }

}
