package game;

import city.cs.engine.*;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;

/**Creates the shape of the bomb objects and also contains the sound a bomb object makes upon collision with a character*/
public class Bomb extends DynamicBody {
    /** Bomb wav sound files in data */
    private static SoundClip bombSound;
    private static SoundClip bombSound1;

    static {
        try {
            //bombSound = new SoundClip("data/bombSound.wav");
            bombSound1 = new SoundClip("data/bombSound1.wav");
            //System.out.println("Loading bomb sound");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
    }

    /** Everytime I call bomb.destroy() after a collision between my character and a bomb, the bomb sound below occurs.*/
    @Override
    public void destroy() // Everytime I called bomb.destroy() after a collision between my character and a bomb, the bomb sound below occurs.
    {
        bombSound1.play();
        //bombSound.play();
        super.destroy();
    }

    private static final Shape ballShape = new CircleShape(0.75f); //Bomb is a circle, this allows it to roll on its axis.
    private static final BodyImage image =
            new BodyImage("data/corona.png", 1.5f);

    /** Bomb constructor used to create new bomb objects
     * @param world Level the bomb object is created in*/
    public Bomb(World world) {
        super(world, ballShape);
        addImage(image);
    }
    private Bomb bomb;



}
