package game;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class ControlPanel {
    private Game game;
    private JButton quitButton;
    private JButton pauseButton;
    private JButton resumeButton;
    private JPanel mainPanel;
    private JButton saveButton;
    private JButton loadButton;

    public ControlPanel(Game g) {
        this.game = g;
        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        pauseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.setPlayingTrue();
                game.pause();

            }
        });
        resumeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.setPlayingFalse();
                game.pause();
            }

        });
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    GameSaverLoader.save(game.getLevel(), "data/save.txt");
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                System.out.println("Save");
            }
        });
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    GameLevel level = GameSaverLoader.load(game,"data/save.txt");
                    game.setLevel(level);
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                System.out.println("Load");
            }
        });
    }
    public JPanel getMainPanel() {
        return mainPanel;
    }


}
