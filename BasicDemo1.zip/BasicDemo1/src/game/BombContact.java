package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
/**This class is determines what is done when there is a collision between a Bomb object and a Roo object */
public class BombContact implements CollisionListener {
    /** Roo objects are the e.getOtherBody() in this collision*/
    private Roo roo;
    private Game game;
    /** Takes Roo g as the getOtherBody() for bomb contact
     * @param g Roo object */
    public BombContact(Roo g) {
        this.roo = g;
    }
    /** When the a Roo object collides with a bomb the lifeCount reduces until 0. If lifeCount = 0, game over. */
    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof Bomb) { // when the kangaroo collides with a bomb the lifeCount reduces until 0. If lifeCount = 0, game over.
            roo.decrementLives();
            e.getOtherBody().destroy();
            if (roo.getLifeCount() == 0) {
                e.getReportingBody().destroy();
                e.getOtherBody().destroy();
                System.out.println("Game Over! You've run out of lives, Press Quit to exit or press Load (or the L key) to continue from where you saved.");
            }
        }


    }

}

