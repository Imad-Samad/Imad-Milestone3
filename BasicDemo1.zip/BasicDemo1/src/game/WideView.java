package game;

import city.cs.engine.UserView;
import city.cs.engine.World;

import javax.swing.*;
import java.awt.*;

public class WideView extends UserView { //Shows a miniture version of the whole frame in the bottom of the screen. So player can see bombs fallnig from above.
    private Image background;
    private Game game;
    private Roo roo;

    public WideView(World w, Game g, Roo r, int width, int height){
        super(w, 500, 170);
        background = new ImageIcon("data/brickwall.gif").getImage(); // background image is the brickwall gif from the data folder
        game = g;
        roo = r;
    }
    @Override
    protected void paintBackground (Graphics2D g){
        g.drawImage(background, 0, 0, getWidth(), getHeight(), this); //positions the background image into the view

    }
    public void updateWideRoo(Roo roo){ this.roo = roo; }

}
