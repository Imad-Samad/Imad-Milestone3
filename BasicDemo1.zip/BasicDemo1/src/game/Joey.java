package game;

import city.cs.engine.*;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;
/**Creates the shape of the Joey objects and also contains the sound a joey object makes upon collision with a character*/
public class Joey extends Walker {  // Joey is a subclass of walker, DynamicBody is also a subclass of walker.
    private static SoundClip joeySound;

    static {
        try {
            joeySound = new SoundClip("data/joeySound.wav"); //sound made when there is a collision with Joey.
            //System.out.println("Loading bomb sound");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
    }
    /** Everytime I call joey.destroy() after a collision between my character and a joey, the joey sound below occurs.*/
    @Override
    public void destroy()
    {
        joeySound.play();
        super.destroy();
    }

    private static final Shape joeyShape = new PolygonShape( //used to make the shape of a new character
            -0.807f,1.13f,
            0.788f,1.25f,
            0.848f,-1.225f,
            -0.857f,-1.22f,
            -0.867f,0.98f);

    private static final BodyImage image =
            new BodyImage("data/baby.png", 2.5f); // this character is half the size of the 1st.
    /** Joey constructor used to create new joey objects
     * @param world Level the joey object is created in*/
    public Joey(World world) {
        super(world, joeyShape);
        addImage(image);
    }
}
