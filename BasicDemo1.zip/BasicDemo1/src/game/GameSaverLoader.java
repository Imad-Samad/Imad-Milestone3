package game;

import city.cs.engine.DynamicBody;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/**This class is used to save a levels current state to a file and load it in-game upon command */
public class GameSaverLoader {
    /**Used to save a games current state to a file, which includes dynamic body positions
     * @param level Current game level
     * @param fileName redirects to file that game state will be saved onto*/
    public static void save(GameLevel level, String fileName)
            throws IOException { //Incase there is an error.
        boolean append = false;
        FileWriter writer = null;
        try {
            writer = new FileWriter(fileName, append);
            writer.write(level.getLevelName() + "\n"); //Writes the name of the current level.

            for (StaticBody body : level.getStaticBodies()){
                // Don't need to save any.
            }

            for (DynamicBody body : level.getDynamicBodies()){ //preserves the state of the dynamic bodies at the point where save is pressed.
                if (body instanceof Roo){//Saves current data of Roo in game (x,y position and lifecount) to be loaded.
                    writer.write("Roo," + body.getPosition().x + "," +
                            body.getPosition().y + "," +
                            ((Roo) body).getLifeCount() + "\n");
                }
                else if (body instanceof Bomb){ //Saves current data of objects of the Bomb class in game (x,y position) to be loaded.
                    writer.write("Bomb," + body.getPosition().x + "," +
                            body.getPosition().y + "\n");
                }
                else if (body instanceof Joey){//Saves current data of Joey in game (x,y position) to be loaded.
                    writer.write("Joey," + body.getPosition().x + "," +
                            body.getPosition().y + "\n");
                }
                else if (body instanceof Robot){//Saves current data of objcts of the Robot class in game (x,y position) to be loaded.
                    writer.write("Robot," + body.getPosition().x + "," +
                            body.getPosition().y + "\n");
                }
            }

        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }
    /** Loads, what was saved by the save method above, in game
     * @param game Loads in game
     * @param fileName Loads data from fileName
     * @return level and state ofgame that was saved*/
    public static GameLevel load(Game game, String fileName)
            throws IOException
    {
        FileReader fr = null;
        BufferedReader reader = null;
        try {
            System.out.println("Reading " + fileName + " ..."); //message displayed when the load button is pressed or the L key is pressed.
            fr = new FileReader(fileName);
            reader = new BufferedReader(fr);
            String line = reader.readLine();
            //Loads the data at the latest save.
            GameLevel level = null;
            if (line.equals("Level1"))
                level = new Level1(game);
            else if (line.equals("Level2"))
                level = new Level2(game);
            else if (line.equals("Level3"))
                level = new Level3(game);

            line = reader.readLine();
            while (line != null){
                String[] tokens = line.split(",");
                if (tokens[0].equals("Roo")){
                    Roo r = new Roo(level);
                    float x = Float.parseFloat(tokens[1]);
                    float y = Float.parseFloat(tokens[2]);
                    r.setPosition(new Vec2(x,y)); //sets roo object position based on the x,y co-ordinates saved
                    int lc = Integer.parseInt(tokens[3]);
                    r.setLifeCount(lc); //sets the livecount to what it was when save was pressed.

                    level.setRoo(r);

                    JoeyEncounter contact2 = new JoeyEncounter(level, game, r);
                    r.addCollisionListener(contact2); //adds collision listeners to loaded level.

                    BombContact contact = new BombContact(r);
                    r.addCollisionListener(contact);//adds collision listeners to loaded level.

                    RobotContact contact3 = new RobotContact(r);
                    r.addCollisionListener(contact3);//adds collision listeners to loaded level.
                }
                else if (tokens[0].equals("Joey")){
                    Joey j = new Joey(level);
                    float x = Float.parseFloat(tokens[1]);
                    float y = Float.parseFloat(tokens[2]);
                    j.setPosition(new Vec2(x,y));//sets joey object position based on the x,y co-ordinates saved
                }
                else if (tokens[0].equals("Bomb")){
                    Bomb b = new Bomb(level);
                    float x = Float.parseFloat(tokens[1]);
                    float y = Float.parseFloat(tokens[2]);
                    b.setPosition(new Vec2(x,y));//sets bomb object positions based on the x,y co-ordinates saved

                    BombSpawn bombSpawn = new BombSpawn(b, level);
                    b.addCollisionListener(bombSpawn);//adds collision listeners to loaded level.
                }
                else if (tokens[0].equals("Robot")){
                    Robot rt = new Robot(level);
                    float x = Float.parseFloat(tokens[1]);
                    float y = Float.parseFloat(tokens[2]);
                    rt.setPosition(new Vec2(x,y));//sets bomb object positions based on the x,y co-ordinates saved
                    rt.setLinearVelocity(new Vec2(-6.5f+0.5f*2f,0f));//sets the velocity of the robot objects to the loaded level.
                }
                line = reader.readLine();
            }
            return level;
        }
        finally {
            if (reader != null) {
                reader.close();
            }
            if (fr != null) {
                fr.close();
            }
        }
    }

}
