package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
/**This class is determines what is done when there is a collision between a Joey object and a Roo object */
public class JoeyEncounter implements CollisionListener {
    /** Roo objects are the e.getOtherBody() in this collision*/
    private Roo roo;
    private GameLevel level;
    private Game game;
    //private int score;
    /** Takes Roo j as the getOtherBody() for bomb contact.
     * @param j Roo object.
     * @param level Level the joey collision occurs.
     * @param game The game this collision occurs.*/
    public JoeyEncounter(GameLevel level, Game game, Roo j) {
        this.level = level;
        this.game = game;
        this.roo = j;
    }

    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof Joey) { // if the kangaroo collides with it's joey, the user wins the game and receives certain messages.
            //student.decrementLives();
            e.getOtherBody().destroy();
            game.goToNextLevel();
            if (roo.getLifeCount() == 3) {
                System.out.println("Well-done! You've managed to rescue your joey with " + roo.getLifeCount() + " lives remaining");
               // score = score + 150;
            }
            else if (roo.getLifeCount() == 2) {
                System.out.println("Well-done! You've rescued your joey with " + roo.getLifeCount() + " lives remaining");
               // score = score + 100;
            } else if (roo.getLifeCount() == 1) {
                System.out.println("Well-done! You've managed to rescue your joey with only " + roo.getLifeCount() + " life remaining");
              //  score = score + 50;
            }
        }
    }
}
