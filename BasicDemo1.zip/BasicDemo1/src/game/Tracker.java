package game;

import city.cs.engine.StepEvent;
import city.cs.engine.StepListener;
import org.jbox2d.common.Vec2;

public class Tracker implements StepListener { //used to follow movements of the character.
    private Myview view; // changed Gameview to Myview.
    private Roo roo;
    public Tracker(Myview view, Roo roo) {
        this.view = view;
        this.roo = roo;
    }
    public void preStep(StepEvent e) {}
    public void postStep(StepEvent e) {
        view.setCentre(new Vec2(roo.getPosition()));
    }
}