package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
/**When a Bomb object collides with a Platform object a new bomb is created to fall, this process is looped*/
public class BombSpawn implements CollisionListener {
    private Bomb bomb;
    private GameLevel gameLevel;
    private int newBombs;
    /**@param b The Bomb objet that collides with the platform.
     * @param gw the level the game is currently in.         */
    public BombSpawn(Bomb b, GameLevel gw) { //This class is used to spawn a loop of bombs the character has to dodge.
        this.bomb = b;
        this.gameLevel = gw;
    }
    @Override
    public void collide(CollisionEvent r) {
        if (r.getOtherBody() instanceof Platform){ // When a bomb collides with a platform, a new bombs is created to fall. This creates the loop.
            newBombs++;
            if (gameLevel.instances < 100 && newBombs <= 1) { // Loop of 100 bombs, technically, for level1, one could wait until all 100 bombs fall and then move, but that would be quite time consuming.
                gameLevel.createBomb(); // calls the createBomb method in GameLevel.
            }

        }

    }

}

